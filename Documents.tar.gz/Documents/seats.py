import re
import json
from copy import deepcopy
from flask import g, request, current_app
from injector import inject
from functools import partial
from boltons.iterutils import remap

from coredial.validation.util import is_valid_uuid_v4
from switchconnex.flask.content_types import json as json_type, Produces, Consumes
from switchconnex.flask.errors import BadRequest, NotFound, Forbidden

from switchconnex.service_pbx.api.v1 import api
from switchconnex.service_pbx.app.authorization.interface import AuthorizationServiceInterface
from switchconnex.service_pbx.app.authorization.constants import USER_ROLE_STANDARD_USER
from switchconnex.service_pbx.app.crud import CRUDRunnerServiceInterface
from switchconnex.service_pbx.app.nextstep import NextStepDestination
from switchconnex.service_pbx.app.validation import Validator, APICollectionQueryValidator
from switchconnex.service_pbx.mailbox.interface import MailboxCRUDServiceInterface
from switchconnex.service_pbx.phone_number.interface import (
    PhoneNumberCRUDServiceInterface, PhoneNumberDAOInterface)
from switchconnex.service_pbx.phone_number.model import PhoneNumber
from switchconnex.service_pbx.seat.interface import (PhoneModelDAOInterface,
                                                     SeatCRUDServiceInterface,
                                                     ManufacturerDAOInterface)
from switchconnex.service_pbx.app.api.price_plan import PricePlanClientInterface
from switchconnex.service_pbx.seat.constants import *
from switchconnex.service_pbx.seat.model import Seat, Privacy, SeatForward
from switchconnex.service_pbx.seat.nextstep import SeatDestination
from switchconnex.service_pbx.endpoint.interface import EndpointCRUDServiceInterface
from switchconnex.service_pbx.extension.constants import *
from switchconnex.service_pbx.extension.model import Extension
from switchconnex.service_pbx.site.dao import SiteDAOInterface
from switchconnex.service_pbx.api.v1.phone_numbers import (
    number_internal_to_api_detail)
from switchconnex.service_pbx.calling_plan.interface.crud_service import CallingPlanServiceInterface
from switchconnex.service_pbx.line_key_config.service import LineKeyConfigService
from switchconnex.service_pbx.seat.interface import EndpointDAOInterface
from sqlalchemy.pool import QueuePool
from switchconnex.service_pbx.app.db import get_engine

from switchconnex.service_pbx.app.nextstep.constants import ORIGIN_SUB_TYPE_ASSIGNED

class db_utilities():
    def __init__(self):
        def get_db_engine(app):
            return get_engine(url=app.config['DB_URL'], timeout=app.config['DB_POOL_TIMEOUT'],
                              pool_size=app.config['DB_POOL_SIZE'], echo=app.config['DB_ECHO'],
                              echo_pool=app.config['DB_ECHO_POOL'], logging_name='flask_engine',
                              poolclass=QueuePool, log_query_performance=app.config['LOG_QUERY_PERFORMANCE'])

        def get_db_connection(engine):
            return engine.connect()

        self.database_connection = get_db_connection(engine=get_db_engine(app=current_app))

def seat_list_mapper(seat, price_plan_id):
    """External representation mapper for Broadworks Seats"""

    if seat['originType'] == 'phone-number':
        assigned_number_repr = {
            "site_id": seat['tnSiteId'],
            "cnam": seat['cnam'],
            "toll_free": seat['tollFree'],
            "state": seat['state'],
            "number": seat['originId'],
            "customer_org_id": seat['customerOrgId'],
            "destination": {
                "type": seat['destinationType'],
                "value": seat['destinationValue']
            },
          "is_default_clid": False,
          "is_assigned_tn": seat['originSubType'] == ORIGIN_SUB_TYPE_ASSIGNED,
        }
    else:
        assigned_number_repr = {
            'toll_free': None,
            'destination': {
                'type': None,
                'value': None
            },
            'site_id': None,
            'number': None,
            'state': None,
            'cnam': None,
            'customer_org_id': None,
            'is_default_clid': False,
            'is_assigned_tn': False,
        }
    default_clid_repr = {
            'toll_free': seat['default_clid_tollFree'],
            'destination': {
                'type': seat['default_clid_destinationType'],
                'value': seat['default_clid_destinationValue'],
            },
            'site_id': seat['default_clid_siteId'],
            'number': seat['default_clid_number'],
            'state': seat['default_clid_state'],
            'cnam': seat['default_clid_cnam'],
            'customer_org_id': seat['default_clid_customerOrgId'],
            'is_default_clid': True,
            'is_assigned_tn': seat['default_clid_originSubType'] == ORIGIN_SUB_TYPE_ASSIGNED,
    }

    repr = {
        "assigned_number": assigned_number_repr,
        "caller_id": seat['callerId'],
        "caller_id_numbers": {
            CALLER_ID_SITE_DEFAULT: default_clid_repr,
            CALLER_ID_SEAT_ASSIGNED: assigned_number_repr,
        },
        "customer_id": seat['customerId'],
        "customer_org_id": seat['customerOrgId'],
        "e911_location_id": seat['e911LocationId'],
        "first_name": seat['firstName'],
        "last_name": seat['lastName'],
        "username": seat['username'],
        "mailbox_status": seat['mailboxStatus'],
        "site_id": seat['siteId'],
        "timezone": seat['timezone'],
        "type": seat['type'],
        "network_type": seat['networkType'],
        "id": str(seat['id']),
        "extension": seat['extensionNumber'],
        "mailbox_id": str(seat['mailboxId']) if seat['mailboxStatus'] else None,
        "user_id": str(seat['userId']),
        "created_time": seat['created'].isoformat('T') if hasattr(seat['created'], 'isoformat') else None,
        "updated_time": seat['updated'].isoformat('T') if hasattr(seat['updated'], 'isoformat') else None,
        "pricePlanId": price_plan_id
    }
    if seat['default_clids']:
        if seat['defaultCLIDNumber'] is not None:
            seat['assigned_number'].update({'is_default_clid': True})
        if seat['originSubType'] == 'assigned':
            seat['assigned_number'].update({'is_assigned_tn': True})
    return repr

@api.route('/seats', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface,
        site_dao=SiteDAOInterface,
        price_plan_client=PricePlanClientInterface)
@Produces(json_type)
def get_seats(crud, auth, site_dao, price_plan_client):
    """
    Get all Seats for a given customer.

    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    :type site_dao: SiteDAOInterface
    """
    validator = APICollectionQueryValidator(sort_fields=('first_name', 'last_name', 'extension', 'phone_number'))

    """
    TIP:
    The name of this should match the backendKey from Angular in the Frontend
    if you have anything that won't match, a 400 will be returned.
    """
    validator.build_collection_filter({
        'first_name': {
            'type': 'string',
            'minlength': 1,
            'maxlength': 255,
        },
        'last_name': {
            'type': 'string',
            'minlength': 1,
            'maxlength': 255,
        },
        'extension': {
            'type': 'string',
            'regex': r'\d+',
        },
        'phone_number': {
            'type': 'string',
            'minlength': 1,
            'maxlength': 10,
        },
        'caller_id': {
            'type': 'string',
            'minlength': 1,
            'maxlength': 10,
        },
        'site_id': {
            'min': 1,
            'coerce': int,
        },
        'seat_type': {
            'min': 1,
            'coerce': int,
        },
        'mailbox_status': {
            'min': 0,
            'max': 1,
            'coerce': int,  # forces the mailbox_status":["0"] coming as a str
        }
    })
    validator.root_schema.update({
        'customer_org_id': {
            'type': 'integer',
            'coerce': int,
            'min': 1,
            'required': True
        },
        'type': {
            'type': 'string',
            'allowed': [Seat.type_names[SEAT_TYPE_STANDARD],
                        Seat.type_names[SEAT_TYPE_PREMIUM],
                        Seat.type_names[SEAT_TYPE_STANDALONE_MAILBOX],
                        Seat.type_names[SEAT_TYPE_UC]],
            'required': False,
        },
        'user_id': {
            'coerce': int,
            'required': False
        },
        'pricePlanId': {
            'coerce': int,
            'required': False
        }
    })
    params_raw = request.args.to_dict()
    if 'filter' in params_raw:
        params_raw['filter'] = json.loads(params_raw['filter'])

    params = validator.validated(params_raw)

    if params is None:
        raise BadRequest(message='Malformed query string',
                         fields=validator.errors)

    auth.require_organization_access(params['customer_org_id'])

    # Unpack the coerced sort parameters from the validator
    # so the DAO can use it
    if 'sort' in params:
        params.update(**params['sort'])
        del params['sort']

    if 'filter' in params:
        params.update(**params['filter'])
        del params['filter']

    # Asking to sort by Site ID translates to alphabetic sorting by site name
    if 'sortfield' in params and params['sortfield'] == 'site_id':
        params['sortfield'] = 'site_name'

    if 'type' in params:
        params['type'] = Seat.type_codes[params['type']]

    result = crud.take_action(service=SeatCRUDServiceInterface, action='fetch_anhydrous_search', **params)
    seat_ids = [seat['id'] for seat in result]
    response_payload = []

    if result.total_count > 0:
        price_plan_ids = price_plan_client.get_seat_price_plans(result[0]['customerId'])

        for seat in result:
            price_plan_id = None

            if price_plan_ids:
                price_plan_id = price_plan_ids.get(str(seat['id']))
            response_payload.append(
                seat_list_mapper(seat, price_plan_id))

    return response_payload, 200, {'X-TOTAL-COUNT': result.total_count}


@api.route('/seats', methods=['POST'])
@inject(phone_model_dao=PhoneModelDAOInterface,
        phone_number_dao=PhoneNumberDAOInterface,
        site_dao=SiteDAOInterface,
        crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface,
        calling_plan_service=CallingPlanServiceInterface)
@Consumes(json_type)
@Produces(json_type)
def create_seat(
        phone_model_dao,
        phone_number_dao,
        site_dao,
        crud,
        auth,
        calling_plan_service):
    """
    Create a new Seat.

    :type phone_model_dao: PhoneModelDAOInterface
    :type phone_number_dao: PhoneNumberDAOInterface
    :type site_dao: SiteDAOInterface
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    :type calling_plan_service: CallingPlanServiceInterface

    :rtype: dict[str, any]
    """
    contract_validator = SeatCreateContractValidator()
    post_data = g.get('parsed_data')

    # correctly set up values that may not be properly set on creation
    post_data['assigned_number'] = None
    post_data['caller_id'] = CALLER_ID_SEAT_ASSIGNED

    price_plan = None
    if 'price_plan' in post_data:
        price_plan = post_data['price_plan']
        del post_data['price_plan']

    # Get site default caller ID
    site = site_dao.fetch_first_matching(
        id=post_data['site_id']
    )
    default_caller_id = phone_number_dao.fetch_first_matching(
        number=site.clid_number
    )

    post_data['caller_id_numbers'] = dict(
        site_cid=(default_caller_id
                 if default_caller_id
                 else PhoneNumber()),
        seat_tn=PhoneNumber()
    )

    payload = contract_validator.validated(post_data)
    if payload is None:
        raise BadRequest(message='Seat failed validation',
                         fields=contract_validator.errors)

    if payload['type'] == SEAT_TYPE_STANDALONE_MAILBOX:
        raise BadRequest(message="Mailbox Seats may not be accessed via this API")

    auth.require_organization_access(payload['customer_org_id'])

    if 'user_id' in payload and payload['user_id'] is not None:
        seat_user_organization_id = auth.get_organization_id_from_customer_user_id(payload['user_id'])
        if seat_user_organization_id != payload['customer_org_id']:
            raise Forbidden("Invalid user ID.")

    auth_user_role = auth.get_user_role()
    auth_user_level = auth.get_user_level()

    if auth_user_role == USER_ROLE_STANDARD_USER and \
                    auth_user_level == 4:
        raise Forbidden("User cannot create seat.")

    mailbox_action = payload.pop('mailbox_action', None)

    payload['user_level'] = auth_user_level

    seat = seat_api_to_internal(payload)

    include_mailbox = (mailbox_action == 'Add')

    seat.mailbox_status = include_mailbox

    calling_plan = calling_plan_service.fetch_by_customer(payload['customer_org_id'])

    crud.queue_create(service=SeatCRUDServiceInterface,
                      seat=seat,
                      include_mailbox=include_mailbox,
                      calling_plan=calling_plan,
                      price_plan=price_plan)

    if include_mailbox:
        populate_seat_mailbox_data(seat)
        crud.queue_create(service=MailboxCRUDServiceInterface,
                          mailbox=seat.mailbox,
                          seat=seat)

    crud.run_actions()

    return seat_internal_to_api(seat, site_dao), 201


@api.route('/seats/<seat_id>', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface,
        phone_model_dao=PhoneModelDAOInterface,
        site_dao=SiteDAOInterface,
        auth=AuthorizationServiceInterface)
@Produces(json_type)
def get_seat(seat_id, crud, phone_model_dao, site_dao, auth):
    """
    Fetch a Seat record.

    :type seat_id: Seat identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type phone_model_dao: PhoneModelDAOInterface
    :type site_dao: SiteDAOInterface
    :type auth: AuthorizationServiceInterface
    """
    if not is_valid_uuid_v4(seat_id):
        raise BadRequest('Invalid Seat ID')

    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)

    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and seat.user_id != auth.get_user_id()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    auth.require_organization_access(seat.customer_org_id)
    headers = {}
    try:
        if seat.realtime_failover == True:
            # Set headers such that the consumer can know which sections had to failover from real-time to service db
            # and when this data is valid as of
            headers = {'X-SC-REALTIME-FAILOVER': 1,
                       'X-SC-FAILOVER-SECTIONS': ['privacies', 'forwards'],
                       'X-SC-PRIVACIES-VALID-AS-OF': seat.privacies_valid_as_of,
                       'X-SC-FORWARDS-VALID-AS-OF': seat.forwards_valid_as_of}
    except AttributeError:
        pass
    return seat_internal_to_api(seat, site_dao), 200, headers

# stub for linekeyconfigs GET endpoint
@api.route('/seats/<seat_id>/linekeyconfigs', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
@Produces(json_type)
def get_linekey_configs(seat_id, crud, auth):
    """
    Fetch linekeyconfig records.

    :type seat_id: Seat identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)
    lineKeyConfig = LineKeyConfigService()
    auth.require_organization_access(seat.customer_org_id)
    configs = lineKeyConfig.fetch_line_key_configs(seat_id)

    return configs, 200, {'X-TOTAL-COUNT': len(configs)}

# stub for linekeyconfigs POST endpoint
@api.route('/seats/<seat_id>/linekeyconfigs', methods=['POST'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
@Produces(json_type)
@Consumes(json_type)
def create_linekey_configs(seat_id, crud, auth):
    """
    Create a lineKeyConfig record.

    :type seat_id: Seat identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    description = 'My Line Keys'
    parsed_json = g.get('parsed_data')
    if 'description' in parsed_json:
        description = str(parsed_json['description'])

    if 'lineKeys' in parsed_json and parsed_json['lineKeys'] is not None:
        try:
            seat_id = parsed_json['lineKeys'][0]['seatId']
        except KeyError:
            raise NotFound(message='Seat {} not found'.format(seat_id))

    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)
    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                         seat.user_id != auth.get_user_id() and \
                         4 == auth.get_user_level()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    auth.require_organization_access(seat.customer_org_id)
    lineKeyConfig = LineKeyConfigService()
    result = lineKeyConfig.create_line_key_config(seat=seat, descr=description)

    return result, 200, {'X-TOTAL-COUNT': len(result)}

# IGNORE! NEED APIB FIXED
@api.route('/seats/<seat_id>/linekeyconfigs/<config_id>', methods=['PUT'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
@Produces(json_type)
@Consumes(json_type)
def update_linekey_configs(seat_id):
    config_id = None
    lineKeyConfig = LineKeyConfigService()
    description = 'My Line Keys'
    parsed_json = g.get('parsed_data')
    if 'id' in parsed_json:
        config_id = int(parsed_json['id'])
    elif 'description' in parsed_json:
        description = str(parsed_json['description'])
    else:
        raise NotFound(message='Seat {} not found'.format(seat_id))

    if 'lineKeys' in parsed_json and parsed_json['lineKeys'] is not None:
        try:
            line_keys = parsed_json['lineKeys']
        except KeyError:
            pass
        else:
            lineKeyConfig.update_line_key(line_keys)

    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)
    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and seat.user_id != auth.get_user_id() and \
                         4 == auth.get_user_level()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    auth.require_organization_access(seat.customer_org_id)

    #original_config = lineKeyConfig.fetch_a_line_key_config(seat, config_id)
    #if original_config['']:
    result = lineKeyConfig.update_linek_key_config_seat(config_id=linekeyconfigid, description=description, seat=seat)
    return result, 204, {'X-TOTAL-COUNT': len(result)}

# stub for linekeyconfig GET endpoint
@api.route('/seats/<seat_id>/linekeyconfig/<config_id>', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
@Produces(json_type)
def get_a_linekey_config(seat_id, config_id, crud, auth):
    """
    Fetch a LineKeyConfig.

    :type seat_id: Seat identifier to search for
    :type config_id: LineKeyConfig identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)
    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                         seat.user_id != auth.get_user_id() and \
                         4 == auth.get_user_level()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    auth.require_organization_access(seat.customer_org_id)
    lineKeyConfig = LineKeyConfigService()
    result = lineKeyConfig.fetch_a_line_key_config(config_id=int(config_id), seat_id=seat_id)
    return result, 200, {'X-TOTAL-COUNT': len(result)}

@api.route('/seats/<seat_id>/linekeyconfig2/<config_id>', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
@Produces(json_type)
def get_linekey_config(seat_id, config_id, crud, auth):
    """
    Fetch a LineKeyConfig.

    :type seat_id: Seat identifier to search for
    :type config_id: LineKeyConfig identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)
    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                         seat.user_id != auth.get_user_id() and \
                         4 == auth.get_user_level()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    auth.require_organization_access(seat.customer_org_id)
    lineKeyConfig = LineKeyConfigService()
    db_connect = db_utilities()
    result = lineKeyConfig.fetch_one_line_key_config(config_id=int(config_id), seat_id=seat_id, db=db_connect)
    return result, 200, {'X-TOTAL-COUNT': len(result)}

# stub for linekeyconfigs DELETE endpoint
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
@api.route('/seats/<seat_id>/linekeyconfigs/<config_id>', methods=['DELETE'])
@Produces(json_type)
def delete_linekey_configs(crud, auth, seat_id, config_id):
    """
    Delete a LineKeyConfig.

    :type seat_id: Seat identifier to search for
    :type config_id: LineKeyConfig identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)
    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                         seat.user_id != auth.get_user_id() and \
                         4 == auth.get_user_level()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    auth.require_organization_access(seat.customer_org_id)
    lineKeyConfig = LineKeyConfigService()
    result = lineKeyConfig.delete_line_key_config(config_id=config_id)
    return result, 204, {'X-TOTAL-COUNT': len(result)}

@api.route('/seats/<seat_id>/endpoints', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface,
        phone_model_dao=PhoneModelDAOInterface)
@Produces(json_type)
def get_seat_endpoints(seat_id, crud, auth, phone_model_dao):
    """
    Fetch a Seat's endpoints.

    :type seat_id: Seat identifier to search for
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)

    if seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                         seat.user_id != auth.get_user_id() and \
                         4 == auth.get_user_level()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    if seat.type == SEAT_TYPE_STANDALONE_MAILBOX:
        raise BadRequest(message="Mailbox Seats may not be accessed via this API")

    auth.require_organization_access(seat.customer_org_id)
    endpoints = crud.fetch_search(service=EndpointCRUDServiceInterface, seat_id=seat_id)

    def render_endpoint(endpoint):
        dms_id = phone_model_dao.get_dms_id_for_endpoint(endpoint)
        return endpoint_internal_to_api(dms_id, endpoint)
    result = map(render_endpoint, endpoints)

    return result, 200, {'X-TOTAL-COUNT': len(result)}


@api.route('/seats/<seat_id>', methods=['PUT'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface,
        calling_plan_service=CallingPlanServiceInterface)
@Consumes(json_type)
def update_seat(seat_id,
                crud,
                auth,
                calling_plan_service):
    """
    Update a Seat record.

    :type seat_id: Seat to update
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    :type calling_plan_service: CallingPlanServiceInterface
    """
    if not is_valid_uuid_v4(seat_id):
        raise BadRequest('Invalid Seat ID')

    existing_seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)

    if existing_seat is None or \
            (auth.get_user_role() == USER_ROLE_STANDARD_USER and existing_seat.user_id != auth.get_user_id()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    if existing_seat.type == SEAT_TYPE_STANDALONE_MAILBOX:
        raise BadRequest(message="Mailbox Seats may not be accessed via this API")

    auth.require_organization_access(existing_seat.customer_org_id)

    # Enforce contract.
    contract_validator = SeatUpdateContractValidator()
    parsed_json = g.get('parsed_data')
    parsed_json['id'] = seat_id

    # correctly set up assigned_number for validation
    try:
        if parsed_json['assigned_number']:
            parsed_json['assigned_number'] =\
                parsed_json['assigned_number']['number']
        else:
            parsed_json['assigned_number']= None
    except KeyError:
        parsed_json['assigned_number'] = None

    price_plan = None
    if 'price_plan' in parsed_json:
        price_plan = int(parsed_json['price_plan'])
        del parsed_json['price_plan']

    payload = contract_validator.validated(parsed_json)
    if payload is None:
        raise BadRequest(message='Seat failed validation',
                         fields=contract_validator.errors)
    mailbox_action = payload.pop('mailbox_action', None)
    include_mailbox = mailbox_action is not None

    payload['user_level'] = auth.get_user_level()

    if 'user_id' in payload and payload['user_id'] is not None:
        seat_user_organization_id = auth.get_organization_id_from_customer_user_id(payload['user_id'])
        if seat_user_organization_id != existing_seat.customer_org_id:
            raise Forbidden("Invalid user ID.")

    if payload['extension'] != existing_seat.extension.number and \
                    auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                    auth.get_user_level() == 4:
        raise Forbidden("Invalid extension change.")

    updated_seat = seat_api_to_internal(payload, existing_seat)

    existing_seat_assigned_number = (existing_seat.assigned_number.number if
                                     existing_seat.assigned_number else None)

    if existing_seat_assigned_number != updated_seat.assigned_number:
        updated_seat_number = None
        if updated_seat.assigned_number is not None:
            updated_seat_number = crud.take_action(
                service=PhoneNumberCRUDServiceInterface,
                action='require_number_for_customer_org',
                number=updated_seat.assigned_number,
                customer_org_id=updated_seat.customer_org_id
            )

        # Disallow TN stealing
        if (updated_seat_number is not None
                and updated_seat_number.nextstep.destination.is_hydrated()
                and updated_seat_number.nextstep.destination != SeatDestination(value=updated_seat.id)):
            raise BadRequest(errors=["{} is not available for assignment to this seat.".format(updated_seat_number.number)])

        existing_seat_number = None
        if existing_seat.assigned_number is not None:
            existing_seat_number = crud.take_action(
                service=PhoneNumberCRUDServiceInterface,
                action='require_number_or_none',
                number=existing_seat.assigned_number['number'],
                customer_org_id=existing_seat.customer_org_id
            )

        # Disallow if seat has a primary number and alternate number
        if (updated_seat_number is None
                and existing_seat.assigned_number.number is not None
                and len(existing_seat.alternate_numbers) > 0):
            raise BadRequest(errors=["This seat must have an Assigned TN."])

        # This catches the use case of a user selecting one of a Premium or UC Seat's alternate TNs to be its assigned TN
        elif (updated_seat.type in [SEAT_TYPE_PREMIUM, SEAT_TYPE_UC]
                and updated_seat.assigned_number in updated_seat.alternate_numbers):
            existing_seat_number = updated_seat_number

        if existing_seat_number is not None and updated_seat_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='move_seat_assigned_tn',
                              from_number=existing_seat_number,
                              to_number=updated_seat_number)

        elif existing_seat_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='unroute',
                              phone_number=existing_seat_number)

        elif updated_seat_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='route_to_seat',
                              phone_number=updated_seat_number,
                              seat=updated_seat)

    calling_plan = calling_plan_service.fetch_by_customer(existing_seat.customer_org_id)

    crud.queue_update(service=SeatCRUDServiceInterface,
                      updated_seat=updated_seat,
                      include_mailbox=include_mailbox,
                      calling_plan=calling_plan,
                      price_plan=price_plan)

    if mailbox_action == 'Add':
        updated_seat.mailbox_status = True
        populate_seat_mailbox_data(updated_seat)
        crud.queue_create(service=MailboxCRUDServiceInterface,
                          mailbox=updated_seat.mailbox,
                          seat=updated_seat)
    elif mailbox_action == 'Delete':
        updated_seat.mailbox_status = False
        crud.queue_delete(service=MailboxCRUDServiceInterface,
                          mailbox=updated_seat.mailbox,
                          seat=updated_seat)

    crud.run_actions()

    return 204


@api.route('/seats/<seat_id>', methods=['PATCH'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface,
        calling_plan_service=CallingPlanServiceInterface)
@Consumes(json_type)
def patch_seat(seat_id,
               crud,
               auth,
               calling_plan_service):
    """
    Update a Seat record with a partial payload. This method supports
    a subset of that which can be POSTed or PUT. Extension, assigned #,
    mailbox, etc. cannot be updated at this time.

    :type seat_id: Seat to update
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    :type calling_plan_service: CallingPlanServiceInterface
    """
    if not is_valid_uuid_v4(seat_id):
        raise BadRequest('Invalid Seat ID')

    existing_seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)

    if existing_seat is None or \
        (auth.get_user_role() == USER_ROLE_STANDARD_USER and existing_seat.user_id != auth.get_user_id()):
        raise NotFound(message='Seat {} not found'.format(seat_id))

    existing_seat_assigned_number = existing_seat.assigned_number.number

    auth.require_organization_access(existing_seat.customer_org_id)

    # Enforce contract.
    contract_validator = SeatPatchContractValidator()
    parsed_json = g.get('parsed_data')
    parsed_json['id'] = seat_id
    # HACK: The validation stuff requires the seat type; we throw it in if it doesn't exist
    if 'type' not in parsed_json:
        parsed_json['type'] = existing_seat.type

    price_plan = None
    if 'price_plan' in parsed_json:
        price_plan = int(parsed_json['price_plan'])
        del parsed_json['price_plan']

    # correctly set up assigned_number for validation
    try:
        if parsed_json['assigned_number']:
            parsed_json['assigned_number'] =\
                parsed_json['assigned_number'] = None
        else:
            parsed_json['assigned_number'] = None
    except KeyError:
        parsed_json['assigned_number'] = None

    payload = contract_validator.validated(parsed_json)
    if payload is None:
        raise BadRequest(message='Seat failed validation',
                         fields=contract_validator.errors)

    if 'user_id' in payload and payload['user_id'] is not None:
        seat_user_organization_id = auth.get_organization_id_from_customer_user_id(payload['user_id'])
        if seat_user_organization_id != existing_seat.customer_org_id:
            raise Forbidden("Invalid user ID.")

    if 'extension' in payload and payload['extension'] != existing_seat.extension.number and \
                    auth.get_user_role() == USER_ROLE_STANDARD_USER and \
                    auth.get_user_level == 4:
        raise Forbidden("Invalid extension change.")

    updated_seat = seat_patch_to_existing(payload, existing_seat)

    if updated_seat.assigned_number is not None and existing_seat_assigned_number != updated_seat.assigned_number.number:
        updated_seat_number = None
        if updated_seat.assigned_number is not None:
            if updated_seat.assigned_number.number is not None:
                updated_seat_number = crud.take_action(service=PhoneNumberCRUDServiceInterface,
                                                       action='require_number_for_customer_org',
                                                       number=updated_seat.assigned_number.number,
                                                       customer_org_id=updated_seat.customer_org_id)

        # Disallow TN stealing
        if (updated_seat_number is not None
            and updated_seat_number.nextstep.destination.is_hydrated()
            and updated_seat_number.nextstep.destination != SeatDestination(value=updated_seat.id)):
            raise BadRequest(
                errors=["{} is not available for assignment to this seat.".format(updated_seat_number.number)])

        existing_seat_number = None
        if existing_seat_assigned_number is not None:
            existing_seat_number = crud.take_action(service=PhoneNumberCRUDServiceInterface,
                                                    action='require_number_or_none',
                                                    number=existing_seat_assigned_number.number,
                                                    customer_org_id=existing_seat.customer_org_id)

        # This catches the use case of a user selecting one of a Premium or UC Seat's alternate TNs to be its assigned TN
        elif (updated_seat.type in [SEAT_TYPE_PREMIUM, SEAT_TYPE_UC]
              and (updated_seat.assigned_number is not None and existing_seat.in_alt_list(updated_seat.assigned_number.number))):
            existing_seat_number = updated_seat_number

        if existing_seat_number is not None and updated_seat_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='move_seat_assigned_tn',
                              from_number=existing_seat_number,
                              to_number=updated_seat_number)

        elif existing_seat_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='unroute',
                              phone_number=existing_seat_number)

        elif updated_seat_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='route_to_seat',
                              phone_number=updated_seat_number,
                              seat=updated_seat)

    calling_plan = calling_plan_service.fetch_by_customer(existing_seat.customer_org_id)

    crud.queue_update(service=SeatCRUDServiceInterface,
                      updated_seat=updated_seat,
                      include_mailbox=False,
                      calling_plan=calling_plan,
                      price_plan=price_plan)

    crud.run_actions()

    return 204


@api.route('/seats/<seat_id>', methods=['DELETE'])
@inject(crud=CRUDRunnerServiceInterface,
        auth=AuthorizationServiceInterface)
def delete_seat(seat_id,
                crud,
                auth):
    """
    :type seat_id: str
    :type crud: CRUDRunnerServiceInterface
    :type auth: AuthorizationServiceInterface
    """
    if not is_valid_uuid_v4(seat_id):
        raise BadRequest('Invalid Seat ID')

    seat = crud.fetch(service=SeatCRUDServiceInterface, seat_id=seat_id)

    if seat is None:
        # Returning success here preserves the idempotency of this route
        return 204

    if seat.type == SEAT_TYPE_STANDALONE_MAILBOX:
        raise BadRequest(message="Mailbox Seats may not be accessed via this API")

    if auth.get_user_role() == USER_ROLE_STANDARD_USER and auth.get_user_level() == 4:
        raise BadRequest(message="Seat could not be deleted.")

    auth.require_organization_access(seat.customer_org_id)

    if seat.assigned_number is not None:
        existing_number = None
        try:
            existing_number = crud.take_action(service=PhoneNumberCRUDServiceInterface,
                                               action='require_number_for_customer_org',
                                               number=seat.assigned_number,
                                               customer_org_id=seat.customer_org_id)
        except (NotFound, Forbidden):
            pass

        # Prevent the absence or previous reassignment of a number
        # from preventing seat deletion
        if existing_number is not None:
            crud.queue_action(service=PhoneNumberCRUDServiceInterface,
                              action='unroute',
                              phone_number=existing_number)

    crud.queue_action(service=EndpointCRUDServiceInterface,
                      action='delete_seat_endpoints',
                      seat=seat)

    crud.queue_delete(service=SeatCRUDServiceInterface,
                      seat=seat)

    if seat.mailbox.id is not None:
        crud.queue_delete(service=MailboxCRUDServiceInterface,
                          mailbox=seat.mailbox,
                          seat=seat)

    crud.run_actions()

    return 204


@api.route('/seats/phone-models', methods=['GET'])
@inject(manufacturer_dao=ManufacturerDAOInterface)
@Produces(json_type)
def get_phone_models(manufacturer_dao):
    """
    Get all PhoneModels.

    :type phone_model_dao: ManufacturerDAOInterface
    """
    manufacturers = manufacturer_dao.fetch_all()

    response_payload = []
    for manufacturer in manufacturers:
        manufacturer_name = manufacturer.name
        for model in manufacturer.phone_models:
            response_payload.append(phone_model_internal_to_api(manufacturer_name, model))

    return response_payload, 200, {'X-TOTAL-COUNT': manufacturers.total_count}


@api.route('/seats/uc-seat-resellers', methods=['GET'])
@inject(crud=CRUDRunnerServiceInterface)
@Produces(json_type)
def get_uc_seat_resellers(crud):
    results = crud.take_action(
        service=SeatCRUDServiceInterface,
        action='get_uc_seat_resellers'
    )
    return results


def seat_internal_to_api_collection(seat, site_dao):
    """
    Build a collection API representation of a Seat.

    :param seat: Seat to represent.
    :type seat: Seat
    :type site_dao: SiteDAOInterface

    :rtype: dict
    """

    if isinstance(seat.assigned_number, PhoneNumber):
        assigned_number = seat.assigned_number
        default_clid_site = site_dao.fetch_first_matching(
            clid_number=seat.assigned_number.number
        )
    else:
        assigned_number = PhoneNumber()
        default_clid_site = False

    assigned_number_repr = number_internal_to_api_detail(
        assigned_number,
        default_clid_site
    )

    caller_id_numbers = {
        CALLER_ID_SITE_DEFAULT: number_internal_to_api_detail(
            seat.caller_id_numbers[CALLER_ID_SITE_DEFAULT],
            True
        ),
        CALLER_ID_SEAT_ASSIGNED: assigned_number_repr,
    }

    return {
        'assigned_number': assigned_number_repr,
        'caller_id': seat.caller_id,
        'caller_id_numbers': caller_id_numbers,
        'customer_id': seat.customer_id,
        'customer_org_id': seat.customer_org_id,
        'e911_location_id': seat.e911_location_id,
        'extension': seat.extension.number,
        'id': str(seat.id),
        'first_name': seat.first_name,
        'last_name': seat.last_name,
        'mailbox_id': str(seat.mailbox.id) if seat.mailbox.id else None,
        'mailbox_status': seat.mailbox_status,
        'site_id': seat.site_id,
        'timezone': seat.timezone,
        'type': seat.type,
        'user_id': seat.user_id,
        'created_time': seat.created.isoformat('T') if hasattr(seat.created,
                                                               'isoformat') else None,
        'updated_time': seat.updated.isoformat('T') if hasattr(seat.updated,
                                                               'isoformat') else None,
        'network_type': seat.network_type,
    }


def seat_internal_to_api(seat, site_dao):
    """
    Build a detail API representation of a Seat.

    :param seat: Seat to represent.
    :type seat: Seat
    :param dms_id: The DMS ID of the seat
    :type dms_id: str
    :type site_dao: SiteDAOInterface

    :rtype: dict
    """
    seat_api = seat_internal_to_api_collection(seat, site_dao)

    alternate_numbers = []
    for alternate_number in seat.alternate_numbers:
        alternate_number_detail = number_internal_to_api_detail(
            alternate_number,
            site_dao.fetch_first_matching(
                clid_number=alternate_number.number
            )
        )

        alternate_numbers.append(alternate_number_detail)

    caller_id_numbers = {
        CALLER_ID_SITE_DEFAULT: number_internal_to_api_detail(
            seat.caller_id_numbers[CALLER_ID_SITE_DEFAULT],
            site_dao.fetch_first_matching(
                clid_number=seat.caller_id_numbers[CALLER_ID_SITE_DEFAULT].number
            )
        ),
        CALLER_ID_SEAT_ASSIGNED: number_internal_to_api_detail(
            seat.caller_id_numbers[CALLER_ID_SEAT_ASSIGNED],
            site_dao.fetch_first_matching(
                clid_number=seat.caller_id_numbers[CALLER_ID_SEAT_ASSIGNED].number
            )
        )
    }

    seat_api.update({
        'privacy': privacies_internal_to_api(seat.privacies),
        'forward': forwards_internal_to_api(seat.forwards),
        'alternate_numbers': alternate_numbers,
        'caller_id_numbers': caller_id_numbers,
        'username': seat.username,
        'network_type': seat.network_type,
    })

    return seat_api


def endpoint_internal_to_api(dms_id, endpoint):
    """
    Build an API representation of a Seat Endpoint.

    :param endpoint: Endpoint to represent.
    :type endpoint: Endpoint

    :rtype: dict
    """
    dms_url = current_app.config.get('BROADWORKS_DMS_URL')

    return {
        'id': str(endpoint.id),
        'seat_id': str(endpoint.seat_id),
        'description': endpoint.description,
        'manufacturer': endpoint.manufacturer,
        'model': endpoint.model,
        'mac_address': endpoint.mac_address,
        'serial_number': endpoint.serial_number,
        'license': endpoint.license,
        'sip_username': endpoint.sip_username,
        'sip_password': endpoint.sip_password,
        'provisioning_username': endpoint.provisioning_username,
        'provisioning_password': endpoint.provisioning_password,
        'dms': {
            'url': '{}/{}'.format(dms_url, dms_id),
            'username': endpoint.provisioning_username,
            'password': endpoint.provisioning_password
        },
        'is_primary': endpoint.is_primary,
        'lineKeyConfigId': endpoint.lineKeyConfigId,
    }


def privacies_internal_to_api(privacies):
    """
    Build an API representation of a Seat's Privacy settings.

    :param privacies: privacies to represent.
    :type privacies: dict[Privacy]

    :rtype: dict
    """
    privacy_repr = {}

    for privacy_type, privacy in privacies.iteritems():
        privacy_repr[privacy_type] = {
            'status': privacy.status
        }

        if privacy_type is PRIVACY_DO_NOT_DISTURB:
            privacy_repr[privacy_type]['ring_reminder'] = privacy.option

    return privacy_repr


def forwards_internal_to_api(forwards):
    """
    Build an API representation of a Seat's SeatForwards.

    :param forwards: forwards to represent.
    :type forwards: dict[SeatForward]

    :rtype: dict
    """
    forwards_repr = {}

    for forward_type, forward in forwards.iteritems():
        forwards_repr[forward_type] = {
            'status': forward.status,
            'destination': {
                'type': forward.destination.type,
                'value': forward.destination.value,
            },
        }

        if forward_type == FORWARD_TYPE_ALWAYS:
            forwards_repr[forward_type]['ring_reminder'] = forward.option
        elif forward_type == FORWARD_TYPE_NO_ANSWER:
            forwards_repr[forward_type]['number_of_rings'] = forward.option
        elif forward_type is FORWARD_TYPE_SELECTIVE:
            forwards_repr[forward_type]['ring_reminder'] = forward.option
            forwards_repr[forward_type]['criteria'] = []
            for criterion in forward.criteria:
                forwards_repr[forward_type]['criteria'].append(criterion)

    return forwards_repr


def phone_model_internal_to_api(manufacturer_name, phone_model):
    return {
        'manufacturer': manufacturer_name,
        'model': phone_model.model,
        'dms_id': phone_model.dms_id,
        'device_profile_type': phone_model.device_profile_type,
    }


def seat_api_to_internal(api_seat, existing_seat=None):
    """
    Convert an API representation of a Seat to Seat Model.

    :param api_seat: API Seat representation.
    :type api_seat: dict
    :param existing_seat: The existing Seat (needed to have access to immutable data)
    :type existing_seat: Seat

    :rtype: Seat
    """
    # Remove sub-model data for separate mapping
    extension = api_seat.pop('extension')
    privacies = api_seat.pop('privacy')
    forwards = api_seat.pop('forward')
    user_level = api_seat.pop('user_level')

    seat = Seat()
    seat.update({k: v for (k, v) in api_seat.iteritems() if k in seat.keys()})
    seat.extension.number = extension
    seat.extension.site_id = seat.site_id

    if isinstance(existing_seat, Seat):
        # Update operation, set identifying information and transfer submodels
        seat.id = existing_seat.id
        seat.customer_id = existing_seat.customer_id
        seat.customer_org_id = existing_seat.customer_org_id
        seat.site_id = existing_seat.site_id
        seat.created = existing_seat.created
        seat.mailbox_status = existing_seat.mailbox_status
        seat.type = existing_seat.type
        if not seat.password:
            seat.password = existing_seat.password

        if seat.type in [SEAT_TYPE_PREMIUM, SEAT_TYPE_UC]:
            # Numbers are deemed alternate or assigned based on state calculation,
            # we need to transfer that state
            seat.alternate_numbers = existing_seat.alternate_numbers

        seat.privacies = existing_seat.privacies
        seat.forwards = existing_seat.forwards

        seat.extension = existing_seat.extension
        seat.mailbox = existing_seat.mailbox

        seat.extension.number = extension

    for privacy_type, privacy in seat.privacies.iteritems():
        privacy_data = privacies[privacy_type]
        privacy.status = privacy_data['status']

        if privacy_type is PRIVACY_DO_NOT_DISTURB:
            privacy.option = privacy_data['ring_reminder']

    for forward_type, forward in seat.forwards.iteritems():
        forward_data = forwards[forward_type]
        forward.status = forward_data['status']

        forward.destination = NextStepDestination(type=forward_data['destination']['type'],
                                                  value=forward_data['destination']['value'])

        if forward_type == FORWARD_TYPE_ALWAYS:
            forward.option = forward_data['ring_reminder']
        elif forward_type == FORWARD_TYPE_NO_ANSWER:
            forward.option = forward_data['number_of_rings']
        elif forward_type == FORWARD_TYPE_SELECTIVE:
            forward.option = forward_data['ring_reminder']
            forward.criteria = forward_data['criteria']
    return seat


def seat_patch_to_existing(api_seat, existing_seat):
    """
    Convert an API representation of a Seat's patch to a Seat Model.

    :param api_seat: API Seat Patch representation.
    :type api_seat: dict
    :param existing_seat: The existing Seat (needed)
    :type existing_seat: Seat

    :rtype: Seat
    """

    if 'customer_id' in api_seat:
        existing_seat.customer_id = api_seat['customer_id']

    if 'site_id' in api_seat:
        existing_seat.site_id = api_seat['site_id']

    if 'user_id' in api_seat:
        existing_seat.user_id = api_seat['user_id']

    if 'first_name' in api_seat:
        existing_seat.user_id = api_seat['first_name']

    if 'last_name' in api_seat:
        existing_seat.user_id = api_seat['last_name']

    if 'caller_id' in api_seat:
        existing_seat.caller_id = api_seat['caller_id']

    if 'type' in api_seat:
        existing_seat.type = api_seat['type']

    if 'timezone' in api_seat:
        existing_seat.timezone = api_seat['timezone']

    if 'password' in api_seat:
        existing_seat.password = api_seat['password']

    if 'mailbox_status' in api_seat:
        existing_seat.mailbox_status = api_seat['mailbox_status']

    if 'e911_location_id' in api_seat:
        existing_seat.e911_location_id = api_seat['e911_location_id']

    if 'assigned_number' in api_seat:
        existing_seat.assigned_number = api_seat['assigned_number']

    if 'alternate_numbers' in api_seat:
        existing_seat.alternate_numbers = api_seat['alternate_numbers']

    if 'voice_portal_pin' in api_seat:
        existing_seat.voice_portal_pin = api_seat['voice_portal_pin']

    if 'extension' in api_seat:
        existing_seat.extension.number = api_seat['extension']

    if 'privacy' in api_seat:
        privacies = api_seat['privacy']
        for privacy_type, privacy in existing_seat.privacies.iteritems():
            privacy_data = privacies[privacy_type]
            privacy.status = privacy_data['status']

            if privacy_type is PRIVACY_DO_NOT_DISTURB:
                privacy.option = privacy_data['ring_reminder']

    if 'forwards' in api_seat:
        forwards = api_seat['forwards']
        for forward_type, forward in existing_seat.forwards.iteritems():
            forward_data = forwards[forward_type]
            forward.status = forward_data['status']

            forward.destination = NextStepDestination(type=forward_data['destination']['type'],
                                                      value=forward_data['destination']['value'])

            if forward_type == FORWARD_TYPE_ALWAYS:
                forward.option = forward_data['ring_reminder']
            elif forward_type == FORWARD_TYPE_NO_ANSWER:
                forward.option = forward_data['number_of_rings']
            elif forward_type == FORWARD_TYPE_SELECTIVE:
                forward.option = forward_data['ring_reminder']
                forward.criteria = forward_data['criteria']

    return existing_seat


def populate_seat_mailbox_data(seat):
    seat.mailbox.update({
        'busy_greeting': 'default',
        'busy_to_voicemail': True,
        'message_deposit': False,
        'email_address': '',
        'email_attach_audio': False,
        'store_voicemail_on_server': True,
        'email_enabled': False,
        'extended_away_disable_deposit': True,
        'no_deposit_behavior': 'allow_call',
        'transfer_on_zero': False,
        'all_to_voicemail': False,
        'unanswered_greeting': 'default',
        'unanswered_rings': 3,
        'unanswered_to_voicemail': True,
        'voicemail_enabled': True,
    })

    seat.mailbox.seat_id = seat.id
    seat.mailbox.voice_portal_pin = seat.voice_portal_pin


def augment_seat_caller_id_data(seat, default_caller_ids):
    if not seat.caller_id_numbers:
        seat.caller_id_data = {
            CALLER_ID_SITE_DEFAULT: default_caller_ids.get(seat.site_id),
            CALLER_ID_SEAT_ASSIGNED: seat.assigned_number,
        }

    return seat


class SeatCreateContractValidator(Validator):
    """
    Validates the v1 API contract of a Seat for creation.
    """
    def __init__(self, *args, **kwargs):
        self.possible_privacies = {
            'barge_in_block': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
            'anonymous_call_rejection': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
            'directory_privacy': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
            'block_my_caller_id': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
            'call_waiting': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
            'do_not_disturb': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'ring_reminder': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
        }

        self.possible_forwards = {
            'always': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'destination': {
                        'required': True,
                    },
                    'ring_reminder': {
                        'type': 'boolean',
                        'required': True,
                    },
                },
            },
            'busy': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'destination': {
                        'required': True,
                    },
                },
            },
            'noAnswer': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'number_of_rings': {
                        'type': 'integer',
                        'required': True,
                    },
                    'destination': {
                        'required': True,
                    },
                },
            },
            'notReachable': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'destination': {
                        'required': True,
                    },
                },
            },
            'selective': {
                'type': 'dict',
                'required': True,
                'schema': {
                    'status': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'destination': {
                        'required': True,
                    },
                    'ring_reminder': {
                        'type': 'boolean',
                        'required': True,
                    },
                    'criteria': {
                        'type': 'list',
                        'required': True,
                    },
                },
            },
        }

        kwargs['data_schema'] = {
            'extension': {
                'type': 'string',
                'required': True,
                'regex': r'\d+',
                'coerce': 'strip',
            },
            'customer_id': {
                'type': 'integer',
                'required': True,
            },
            'user_id': {
                'type': 'integer',
                'required': False,
                'nullable': True,
            },
            'customer_org_id': {
                'type': 'integer',
                'required': True,
            },
            'site_id': {
                'type': 'integer',
                'required': True,
            },
            'first_name': {
                'type': 'string',
                'required': True,
                'maxlength': 255,
                'coerce': 'strip',
            },
            'last_name': {
                'type': 'string',
                'required': True,
                'maxlength': 255,
                'coerce': 'strip',
            },
            'caller_id': {
                'type': 'string',
                'required': True,
                'nullable': True,
            },
            'type': {
                'type': 'integer',
                'required': True,
                'allowed': Seat.get_types(),
                'coerce': int,
            },
            'timezone': {
                'type': 'string',
                'required': True,
                'nullable': True,
                'validator': 'common_timezone',
            },
            'assigned_number': {
                'type': 'phone_number',
                'required': True,
                'nullable': True,
            },
            'mailbox_action': {
                'type': 'string',
                'required': False,
                'nullable': True,
                'allowed': ['Add'],
            },
            'voice_portal_pin': {
                'type': 'string',
                'required': False,
                'nullable': True,
            },
            'e911_location_id': {
                'type': 'integer',
                'required': True,
                'nullable': True,
            },
            'forward': {
                'type': 'dict',
                'required': True,
                'schema': {},  # Set up at runtime
            },
            'privacy': {
                'type': 'dict',
                'required': True,
                'schema': {},  # Set up at runtime
            },
            'username': {
                'type': 'string',
                'required': True,
                'coerce': 'strip',
                'validator': 'broadworks_username',
            },
            'password': {
                'type': 'string',
                'required': True,
                'maxlength': 60,
                'validator': 'broadworks_password',
            },
            'network_type': {
                'type': 'integer',
                'required': True,
                'allowed': Seat.get_network_types(),
                'coerce': int,
            },
            # Non-DB fields and submodels here down
            'caller_id_numbers': {
                'required': False,
                'nullable': True,
            },
        }

        super(SeatCreateContractValidator, self).__init__(*args, **kwargs)

    def validate(self, seat_data, **kwargs):
        """
        Configures forwards and privacies based on seat type and calls its parent function.

        :param seat_data: dict
        :param kwargs: Arguments passed to the Cerberus validate() function
        :rtype: bool
        """

        # Re-initialize for each validation run
        self.root_schema['forward']['schema'] = {}
        self.root_schema['privacy']['schema'] = {}

        try:
            seat_type = int(seat_data['type'])
        except (TypeError, KeyError):
            # Seat type was missing, let validation do its job and handle the
            # error.
            pass
        else:
            seat_forwards = SeatForward.get_forward_types_for_seat_type(seat_type)
            seat_privacies = Privacy.get_privacy_types_for_seat_type(seat_type)
            for forward in seat_forwards:
                sub_schema = deepcopy(self.possible_forwards[forward])
                self.root_schema['forward']['schema'].update({forward: sub_schema})

            for privacy in seat_privacies:
                sub_schema = deepcopy(self.possible_privacies[privacy])
                self.root_schema['privacy']['schema'].update({privacy: sub_schema})

        return super(SeatCreateContractValidator, self).validate(seat_data, **kwargs)

    def _validator_broadworks_username(self, field, value):
        if not value:
            return
        if not re.match(r'^[-\.:\[\]A-Za-z0-9]+$', value):
            self._error(field, "Username must only consist of (letters, digits, ., -, : and square brackets)")
        if any([len(value) > 80, len(value) < 6]):
            self._error(field, "Username must be between 6 and 80 characters long.")

    def _validator_broadworks_password(self, field, value):
        if not value:
            return
        username = self.document['username']
        username_in_password = username in value if username else False
        is_valid = all([
            not username_in_password,
            re.search(r'\d', value),
            re.search(r'[A-Z]', value),
            re.search(r'[a-z]', value),
            re.search(r'[^\dA-Za-z]', value),
            len(value) >= 6,
            len(value) <= 60,
        ])

        if not is_valid:
            self._error(field, "Invalid Password: "
                               "Cannot contain the login ID. "
                               "Must contain at least 1 number(s). "
                               "Must contain at least 1 uppercase alpha character(s). "
                               "Must contain at least 1 lowercase alpha character(s). "
                               "Must contain at least 1 non-alphanumeric character(s). "
                               "Must be between 6 and 60 characters")


class SeatUpdateContractValidator(SeatCreateContractValidator):
    """
    Validates the v1 API contract of a Seat for updating.
    """

    def __init__(self, *args, **kwargs):
        super(SeatUpdateContractValidator, self).__init__(*args, **kwargs)

        # Set up update-specific contract elements
        self.root_schema['id'] = {
            'type': 'uuid_v4',
            'required': True,
            'nullable': False,
        }
        self.root_schema['username']['empty'] = False
        # L4 users cannot edit endpoints or extensions,
        # so these elements might not be present
        self.root_schema['extension']['required'] = False
        self.root_schema['mailbox_action']['allowed'] = ['Add', 'Delete']


class SeatPatchContractValidator(SeatUpdateContractValidator):
    """
    Validates the v1 API contract of a Seat for PATCHing.
    """
    def __init__(self, *args, **kwargs):
        super(SeatPatchContractValidator, self).__init__(*args, **kwargs)

        def make_optional(path, key, value):
            # ID is always needed, even for PATCH
            if key == 'required' and 'id' not in path:
                return key, False
            return key, value

        # Make all fields optional
        self.possible_forwards = remap(self.possible_forwards, visit=make_optional)
        self.possible_privacies = remap(self.possible_privacies, visit=make_optional)
        # Cerberus' root_schema is a DefinitionSchema object.
        # remap() does not play nicely with it, so cast root_schema to dict
        # and then update root_schema with the result, and as root_schema implements
        # dict access this will get us what we want.
        self.root_schema.update(remap(dict(self.root_schema), visit=make_optional))
