import requests
import xmltodict
import json
from switchconnex.service_integration import default_config
from multiprocessing.dummy import Pool as ThreadPool
from functools import partial
from switchconnex.flask.errors import APIError


class XSIException(APIError):
    pass


def to_bool(a):
    """ Convert a stringy or bool to bool
    :param a: value to convert to boolean
    :return: True or False
    """
    return a == 'true' or a == True

def fix_bool_values(value, keys):
    """ Function to fix the values of the provided keys in the provided dict to boolean """
    try:
        for key in keys:
            if key in value[value.keys()[0]]:
                value[value.keys()[0]][key] = to_bool(value[value.keys()[0]][key])
    except:
        pass
    return value


class SeatClient(object):
    '''
    Service for seat details.
    '''
    API_NAME = 'seat'

    ANONYMOUS_CALL_REJECTION_PATH = '/v2.0/user/{seat_username}/services/anonymouscallrejection'
    BARGE_IN_EXCEMPT_PATH = '/v2.0/user/{seat_username}/services/bargeinexempt'
    CALLER_ID_BLOCKING_PATH = '/v2.0/user/{seat_username}/services/callinglineiddeliveryblocking'
    CALL_WAITING_PATH = '/v2.0/user/{seat_username}/services/callwaiting'
    PRIVACY_PATH = '/v2.0/user/{seat_username}/services/privacy'
    DND_PATH = '/v2.0/user/{seat_username}/services/donotdisturb'
    CALL_FORWARDING_ALWAYS_PATH = '/v2.0/user/{seat_username}/services/CallForwardingAlways'
    CALL_FORWARDING_BUSY_PATH = '/v2.0/user/{seat_username}/services/CallForwardingBusy'
    CALL_FORWARDING_NOANSWER_PATH = '/v2.0/user/{seat_username}/services/CallForwardingNoAnswer'
    CALL_FORWARDING_NOTREACHABLE_PATH = '/v2.0/user/{seat_username}/services/CallForwardingNotReachable'
    CALL_FORWARDING_SELECTIVE_PATH = '/v2.0/user/{seat_username}/services/CallForwardingSelective'
    CALL_FORWARDING_SELECTIVE_CRITERIA_PATH = '/v2.0/user/{seat_username}/services/CallForwardingSelective/criteria/{criteria_name}'

    ACTION_PATH_MAP = {
        'anonymous call rejection': ANONYMOUS_CALL_REJECTION_PATH,
        'barge in exempt': BARGE_IN_EXCEMPT_PATH,
        'caller id blocking': CALLER_ID_BLOCKING_PATH,
        'call waiting': CALL_WAITING_PATH,
        'privacy': PRIVACY_PATH,
        'dnd': DND_PATH,
        'call forwarding always': CALL_FORWARDING_ALWAYS_PATH,
        'call forwarding busy': CALL_FORWARDING_BUSY_PATH,
        'call forwarding no answer': CALL_FORWARDING_NOANSWER_PATH,
        'call forwarding not reachable': CALL_FORWARDING_NOTREACHABLE_PATH,
        'call forwarding selective': CALL_FORWARDING_SELECTIVE_PATH,
        'call forwarding selective criteria': CALL_FORWARDING_SELECTIVE_CRITERIA_PATH
    }
    matches = {'xsi_nil': ' xsi:nil="true"', 'schema': ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
               'namespace': ' xmlns="http://schema.broadsoft.com/xsi"'}
    namespaces = {'http://schema.broadsoft.com/xsi': None}

    def __init__(self):
        pass

    def sanitize(self, x):
        # replace extraneous namespaces and attributes in XML with ''
        sanitized = x.replace(self.matches['xsi_nil'], '')
        sanitized = sanitized.replace(self.matches['schema'], '')
        sanitized = sanitized.replace(self.matches['namespace'], '')

        return sanitized

    def get_xsi_data(self, action, **kwargs):
        """
        Get data for a particular call against the broadworks XSI API.
        :param action: The XSI action to request
        :param kwargs: The parameters that XSI action requires
        :return:
        """
        path = self.ACTION_PATH_MAP[action].format(**kwargs)
        try:
            response = requests.request('GET', "{}{}".format(default_config.API_REGISTRY[self.API_NAME], path),

                                        auth=(default_config.BROADWORKS_XSI_USERNAME, default_config.BROADWORKS_XSI_PASSWORD))
        except requests.RequestException as e:
            return e
        return response

    def get_privacy_services(self, seat_username):
        """
        Get the services in broadworks that switchconnex calls privacies
        :param seat_username: the seat username
        :return: a dictionary of the privacy data
        """
        pool = ThreadPool(6)
        privacy_actions = {'anonymous call rejection', 'barge in exempt', 'caller id blocking', 'call waiting', 'privacy', 'dnd'}

        privacies_list = pool.map(partial(self.get_xsi_data, seat_username=seat_username), privacy_actions)
        def munge_privacies(acc, a):
            if isinstance(a, Exception):
                raise a
            if a.status_code == 200:
                value = xmltodict.parse(self.sanitize(a.content), process_namespaces=True, namespaces=self.namespaces)
                # fix the booleans so they are not strings
                acc.update(fix_bool_values(value, {'active', 'ringSplash',
                                                   'isEnableAutoAttendantExtensionDialingPrivacy',
                                                   'isEnableAutoAttendantNameDialingPrivacy', 'isEnableDirectoryPrivacy',
                                                   'isEnablePhoneStatusPrivacy'}))
            else:
                value = xmltodict.parse(a.content)
                raise XSIException(code=a.status_code, message=value['ErrorInfo']['summary'])
            return acc

        return reduce(munge_privacies, privacies_list, {})

    def get_call_forwarding_services(self, seat_username):
        """
        Get the services in broadworks related to call forwarding
        :param seat_username: the seat username (not the seat id)
        :return: a dictionary of call forwarding data
        """
        pool = ThreadPool(5)
        call_forwarding_actions = {'call forwarding always', 'call forwarding busy', 'call forwarding no answer',
                                   'call forwarding selective', 'call forwarding not reachable',}
        forwarding_list = pool.map(partial(self.get_xsi_data, seat_username=seat_username), call_forwarding_actions)

        def munge_forwarding_services(acc, a):
            if isinstance(a, Exception):
                raise a
            if a.status_code == 200:
                value = xmltodict.parse(a.content, process_namespaces=True, namespaces=self.namespaces)
                # fix the booleans so they are not strings
                if 'CallForwardingSelective' in value:
                    for activation in value['CallForwardingSelective']['criteriaActivations']['criteriaActivation']:
                        activation['active'] = to_bool(activation['active'])
                acc.update(fix_bool_values(value, {'active', 'ringSplash', 'playRingReminder'}))
            else:
                value = xmltodict.parse(a.content)
                raise XSIException(code=a.status_code, message=value['ErrorInfo']['summary'])
            return acc
        return reduce(munge_forwarding_services, forwarding_list, {})

    def get_call_forwarding_selective_criteria_services(self, seat_username, criteria_names):
        """
        Get the criteria details, rules that govern a call forwarding selective, from broadworks
        :param seat_username: the seat username (not the seat id)
        :param criteria_names: the names of the criteria rules for call forwarding selective. These are obtainable
        from the get_call_forwarding_services call
        :return: a dictionary of criteria details
        """
        pool = ThreadPool(len(criteria_names))
        criteria_list = pool.map(lambda x: self.get_xsi_data('call forwarding selective criteria',
                                                 seat_username=seat_username,
                                                 criteria_name=x),
                     criteria_names)
        def munge_criteria_list(acc, a):
            if isinstance(a, Exception):
                raise a
            if a.status_code == 200:
                rec = xmltodict.parse(a.content,  process_namespaces=True, namespaces=self.namespaces)
                # fix the booleans so they are not strings
                if 'criteriaFromDn' in rec['CallForwardingSelectiveCriteria']['criteria']:
                    for key in {'includeAnonymousCallers', 'includeUnavailableCallers'}:
                        if key in rec['CallForwardingSelectiveCriteria']['criteria']['criteriaFromDn']:
                            rec['CallForwardingSelectiveCriteria']['criteria']['criteriaFromDn'][key] = to_bool(rec['CallForwardingSelectiveCriteria']['criteria']['criteriaFromDn'][key])
                acc.update({rec['CallForwardingSelectiveCriteria']['criteria']['criteriaName']: rec['CallForwardingSelectiveCriteria']})
                return acc
            else:
                value = xmltodict.parse(a.content)
                raise XSIException(code=a.status_code, message=value['ErrorInfo']['summary'])
            return acc

        return reduce(munge_criteria_list, criteria_list, {})