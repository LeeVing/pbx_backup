"""create and modify tables for SCA

Revision ID: 96be7fac9390
Revises: 1cc0fbbfd244
Create Date: 2017-08-29 10:44:04.542449

"""

# revision identifiers, used by Alembic.
revision = '96be7fac9390'
down_revision = '1cc0fbbfd244'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa


from alembic import context


def upgrade():
    schema_upgrades()
    data_upgrades()

def downgrade():
    if context.get_x_argument(as_dictionary=True).get('schema', None):
        schema_downgrades()
    if context.get_x_argument(as_dictionary=True).get('data', None):
        data_downgrades()

def schema_upgrades():
    """idempotent schema upgrade migrations go here."""
    conn = op.get_bind()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS `lineKeyConfig` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                           `seat_id` char(36) NOT NULL,
                                           `description` varchar(255) NOT NULL,
                                            INDEX `lineKeyConfig_seat_id_idx`(`seat_id`),
                                            FOREIGN KEY `lineKeyConfig_seat_id_fk`(`seat_id`)
                                                REFERENCES `seat`(`id`)
                                                ON DELETE CASCADE
                                           )
                                           """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS `primaryLineKeyConfig` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                                   `seat_id` char(36) NOT NULL,
                                                   `lineKeyConfigId` INT NOT NULL, 
                                                    INDEX `primaryLineKeyConfig_lineKeyConfigId_idx`(`lineKeyConfigId`),
                                                    INDEX `primaryLineKeyConfig_seat_id_idx`(`seat_id`),
                                                    FOREIGN KEY `primaryLineKeyConfig_seat_id_fk`(`seat_id`)
                                                        REFERENCES `seat`(`id`)
                                                        ON DELETE CASCADE,
                                                    FOREIGN KEY `primaryLineKeyConfig_lineKeyConfigId_fk`(`lineKeyConfigId`)
                                                        REFERENCES `lineKeyConfig`(`id`)
                                                        ON DELETE CASCADE
                                                   )
                                                   """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS `lineKey` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                       `lineKeyConfigId` INT NOT NULL,
                                       `seat_id` char(36) NOT NULL, 
                                       `position` INT NOT NULL,
                                        INDEX `lineKey_lineKeyConfigId_idx`(`lineKeyConfigId`),
                                        INDEX `lineKey_seat_id_idx`(`seat_id`),
                                        FOREIGN KEY `lineKey_seat_id_fk`(`seat_id`)
                                            REFERENCES `seat`(`id`)
                                            ON DELETE CASCADE,
                                        FOREIGN KEY `lineKey_lineKeyConfigId_fk`(`lineKeyConfigId`)
                                            REFERENCES `lineKeyConfig`(`id`)
                                            ON DELETE CASCADE
                                       )
                                       """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS `primaryEndpoint` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                             `seat_id` char(36) NOT NULL,
                                             `endpointId` char(36) NOT NULL,
                                             INDEX `primaryEndpoint_seat_id_idx`(`seat_id`),
                                             INDEX `primaryEndpoint_endpointId_idx`(`endpointId`),
                                             FOREIGN KEY `primaryEndpoint_seat_id_fk`(`seat_id`)
                                                 REFERENCES `seat`(`id`)
                                                 ON DELETE CASCADE,
                                             FOREIGN KEY `primaryEndpoint_endpointId_fk`(`endpointId`)
                                                 REFERENCES `endpoint`(`id`)
                                                 ON DELETE CASCADE
                                            )
                                            """)
    try:
        op.add_column(
            'endpoint',
            sa.Column('lineKeyConfigId', sa.INT,
                      nullable=True, default='NULL')
        )
    except sa.exc.OperationalError as e:
        if e.message == '''(_mysql_exceptions.OperationalError) (1060, "Duplicate column name 'lineKeyConfigId'")''':
            pass
        else:
            raise
    else:
        conn.execute("""
            ALTER TABLE `endpoint` ADD CONSTRAINT `endpoint_lineKeyConfigId` 
            FOREIGN KEY `endpoint_lineKeyConfigId_fk` (`lineKeyConfigId`)
                REFERENCES `lineKeyConfig`(`id`)
                ON DELETE SET NULL
                     """)

def schema_downgrades():
    """remove lineKeyConfigId column and constraint from endpoint"""
    op.drop_constraint('endpoint_lineKeyConfigId', 'endpoint', type_='foreignkey')
    op.drop_column('endpoint', 'lineKeyConfigId')
    # drop primaryEndpoint table
    op.drop_constraint('primaryEndpoint_ibfk_1', 'primaryEndpoint', type_='foreignkey')
    op.drop_constraint('primaryEndpoint_ibfk_2', 'primaryEndpoint', type_='foreignkey')
    op.drop_index('primaryEndpoint_seat_id_idx')
    op.drop_index('primaryEndpoint_endpointId_idx')
    op.drop_table('primaryEndpoint')
    # drop lineKey table
    op.drop_constraint('lineKey_ibfk_1', 'lineKey', type_='foreignkey')
    op.drop_constraint('lineKey_ibfk_2', 'lineKey', type_='foreignkey')
    op.drop_index('lineKey_lineKeyConfigId_idx')
    op.drop_index('lineKey_seat_id_idx')
    op.drop_table('lineKey')
    # drop primaryLineKeyConfig table
    op.drop_constraint('primaryLineKeyConfig_ibfk_1', 'primaryLineKeyConfig', type_='foreignkey')
    op.drop_constraint('primaryLineKeyConfig_ibfk_2', 'primaryLineKeyConfig', type_='foreignkey')
    op.drop_index('primaryLineKeyConfig_lineKeyConfigId_idx')
    op.drop_index('primaryLineKeyConfig_seat_id_idx')
    op.drop_table('primaryLineKeyConfig')
    # drop lineKeyConfig table
    op.drop_constraint('lineKeyConfig_ibfk_1', 'lineKeyConfig', type_='foreignkey')
    op.drop_index('lineKeyConfig_seat_id_idx')
    op.drop_table('lineKeyConfig')

def data_upgrades():
    """Add any optional data upgrade migrations here!"""
    conn = op.get_bind()
    conn.execute("""
        INSERT INTO primaryEndpoint (seat_id, endpointId) 
        SELECT s.id, e.id 
        FROM `seat` s inner join `endpoint` e 
            on s.id = e.seat_id 
        WHERE e.isPrimary > 0
    """)

def data_downgrades():
    """Add any optional data downgrade migrations here! for development purposes only"""
    pass