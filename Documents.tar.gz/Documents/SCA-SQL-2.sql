SET foreign_key_checks = 0;
        CREATE TABLE IF NOT EXISTS `lineKeyConfig` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                           `seat_id` char(36) NOT NULL,
                                           `description` varchar(255) NOT NULL,
                                            INDEX `lineKeyConfig_seat_id_idx`(`seat_id`),
                                            FOREIGN KEY `lineKeyConfig_seat_id_fk`(`seat_id`)
                                                REFERENCES `seat`(`id`)
                                                ON DELETE CASCADE
                                           );
        CREATE TABLE IF NOT EXISTS `primaryLineKeyConfig` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                                   `seat_id` char(36) NOT NULL,
                                                   `lineKeyConfigId` INT NOT NULL, 
                                                    INDEX `primaryLineKeyConfig_lineKeyConfigId_idx`(`lineKeyConfigId`),
                                                    INDEX `primaryLineKeyConfig_seat_id_idx`(`seat_id`),
                                                    FOREIGN KEY `primaryLineKeyConfig_seat_id_fk`(`seat_id`)
                                                        REFERENCES `seat`(`id`)
                                                        ON DELETE CASCADE,
                                                    FOREIGN KEY `primaryLineKeyConfig_lineKeyConfigId_fk`(`lineKeyConfigId`)
                                                        REFERENCES `lineKeyConfig`(`id`)
                                                        ON DELETE CASCADE
                                                   );
                                                   
        CREATE TABLE IF NOT EXISTS `lineKey` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                       `lineKeyConfigId` INT NOT NULL,
                                       `seat_id` char(36) NOT NULL, 
                                       `position` INT NOT NULL,
                                        INDEX `lineKey_lineKeyConfigId_idx`(`lineKeyConfigId`),
                                        INDEX `lineKey_seat_id_idx`(`seat_id`),
                                        FOREIGN KEY `lineKey_seat_id_fk`(`seat_id`)
                                            REFERENCES `seat`(`id`)
                                            ON DELETE CASCADE,
                                        FOREIGN KEY `lineKey_lineKeyConfigId_fk`(`lineKeyConfigId`)
                                            REFERENCES `lineKeyConfig`(`id`)
                                            ON DELETE CASCADE
                                       );
        CREATE TABLE IF NOT EXISTS `primaryEndpoint` (`id` INT AUTO_INCREMENT PRIMARY KEY,
                                             `seat_id` char(36) NOT NULL,
                                             `endpointId` char(36) NOT NULL,
                                             INDEX `primaryEndpoint_seat_id_idx`(`seat_id`),
                                             INDEX `primaryEndpoint_endpointId_idx`(`endpointId`),
                                             FOREIGN KEY `primaryEndpoint_seat_id_fk`(`seat_id`)
                                                 REFERENCES `seat`(`id`)
                                                 ON DELETE CASCADE,
                                             FOREIGN KEY `primaryEndpoint_endpointId_fk`(`endpointId`)
                                                 REFERENCES `endpoint`(`id`)
                                                 ON DELETE CASCADE
                                            );
INSERT INTO primaryEndpoint (seat_id, endpointId) 
SELECT s.id, e.id 
FROM `seat` s inner join `endpoint` e 
    on s.id = e.seat_id 
WHERE e.isPrimary > 0;

ALTER TABLE `endpoint` ADD lineKeyConfigId INT DEFAULT NULL;

            ALTER TABLE `endpoint` ADD CONSTRAINT `endpoint_lineKeyConfigId` 
            FOREIGN KEY `endpoint_lineKeyConfigId_fk` (`lineKeyConfigId`)
                REFERENCES `lineKeyConfig`(`id`)
                ON DELETE SET NULL;

SET foreign_key_checks = 1;

SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE REFERENCED_TABLE_SCHEMA = 'service_pbx' AND REFERENCED_TABLE_NAME = 'lineKeyConfig';
